#Programming Assignment 3

Inorder to run the program, just modify the `input.in` file. There are 6 integers in that file:NDice,NSides,LTarget,UTarget,NGames,M.

After editting that input file, make sure you installed required packages: `pip install numpy`

Then, just use `python3 main.py` to run the program. The output should be two matrices: first one is the best choices under every situation, the second one is the winning probability in every situation. Here is one example output:
```
2 2 2 2 
2 2 2 2 
1 1 1 1 
1 1 1 1 
0.5441807449116332 0.5419222741908017 0.4343925867444026 0.5861113862436858 
0.5318617694952054 0.5363343234271011 0.45732538072602863 0.5726986137913763 
0.6658048869772124 0.6585435106133 0.579230759665245 0.6879505266887187 
0.4759645074267884 0.47661147517675495 0.4379745796336074 0.5008105752947173 
```